let header = document.getElementById('header');
let burger = document.querySelector('#headmenuburger')
// let headmenu = false;

burger.addEventListener('click', ()=>{
     pushWindow("mobile-menu");
})